function a1_2()
load('d_a1_2.mat')
%%%%%%%%%Plot code for clusters%%%%%%%%%%%%%%%%%%%%%%
X_cluster2 = X_cluster(:,1:2);
col_mtx = [bar_col{1,1}; bar_col{2,1}; bar_col{3,1}]; 
col_mtx = [bar_col{2,1}; bar_col{3,1}; bar_col{1,1}]; 
col_mtx = [bar_col{3,1}; bar_col{1,1}; bar_col{2,1}]; 


k = [3]; % Number of GMM components
nK = numel(k)
options = statset('MaxIter',5000);
Sigma = {'full'}; % Options for covariance matrix type
nSigma = numel(Sigma);

SharedCovariance = {false}; % Indicator for identical or nonidentical covariance matrices
nSC = numel(SharedCovariance);
d = 500; % Grid length
x1 = linspace(min(X_cluster2(:,1))-2, max(X_cluster2(:,1))+2, d);
x2 = linspace(min(X_cluster2(:,2))-2, max(X_cluster2(:,2))+2, d);
[x1grid,x2grid] = meshgrid(x1,x2);
X0 = [x1grid(:) x2grid(:)];
threshold = sqrt(chi2inv(0.99,2));
count = 1;
j = 1        
[obs D] = size(X_cluster2); %number of variables sfor each obs = D
Df = (D*D - D)/2 + 2*D + 1; %number ov params for each guassian (full rather than diag covarianc mtx
%plot 
% Draw ellipsoids over each GMM component and show clustering result.   
clusterX = cluster(gmfit{j,1},X_cluster2); % Cluster index 
mahalDist = mahal(gmfit{j,1},X0); % Distance from each grid point to each GMM component
figure(122)

h1 = gscatter(X_cluster2(:,1),X_cluster2(:,2),clusterX,col_mtx);
hold on
    for m = 1:k(j)
        idx = mahalDist(:,m)<=threshold;
        Color = col_mtx(m,:)*.5;
        h2 = plot(X0(idx,1),X0(idx,2),'.','Color',Color,'MarkerSize',1);
        uistack(h2,'bottom');
    end
title(['Suprasylvian Auditory Areas']);
set (gca,'Xdir','reverse')
pptfig_text(14,14)
legend('off')
count = count + 1;

%**************look at properties of mmodel******************
properties(gmfit{1,1})
gmfit{1,1}.mu
gmfit{1,1}.Sigma
%gmPDF = @(x,y) arrayfun(@(x0,y0) pdf(,[x0 y0]),x,y);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
scatter(gmfit{1,1}.mu(:,1),gmfit{1,1}.mu(:,2),'k')
hold off
