function a2_1()

load('d_a2_1.mat')

bigfigN(130,.34,0.30)
hold
title(['Left Hem. Latency Dist'])
load('cvs_avg35_inMNI152_lh_pial.mat')
ctmr_gauss_plot(cortex,[0 0 0],0,'lh'); 
hold on;

[onsets_all_sorted indsort] = sort(onsets_all,'descend');
region_all_sorted = region_all(indsort);
elecs_all_sorted = elecs_all(indsort); 
elecMTX_all_sorted = elecMTX_all(indsort,:);
NeA = size(elecMTX_all_sorted,1);
x_delta = linspace(0,2,NeA);
elecMTX_all_sorted(:,1) = elecMTX_all_sorted(:,1) + x_delta';%helps visualize lowest latency vals by plotting on top.


for elecj = 1:length(elecs_all_sorted)
   
    elecj
    onj = onsets_all_sorted(elecj);
    regj = region_all_sorted(elecj);


    if regj < 4 %if a suprasylvian region plot all data
            if onj>Ncent
                onj = Ncent;
                rgb = rgbMTX(onj,:);
                rgb = [0 0 0];
                mk_sz = mk_sz1;
                xx = 0;

            else  
                rgb = rgbMTX(onj,:);
                mk_sz = mk_sz2*(210-onj)*0.1;
                if onj < 65
                xx = -4
                else
                xx = -2;
                end
            end

            yrand = (rand(1,1)-0.5)*2;
            zrand = (rand(1,1)-0.5)*2;
            scatter3(elecMTX_all_sorted(elecj,1)+xx,elecMTX_all_sorted(elecj,2)+yrand,elecMTX_all_sorted(elecj,3)+zrand,mk_sz,'MarkerFaceColor',rgb,'MarkerEdgeColor',rgb)

    else %if temporal lobe only plot random ~20% of data so the number of data points are comparable. 
        percent = 0.25;
        if rand(1) < percent %only plot percent of onsets. 
            if onj>Ncent
                onj = Ncent;
                rgb = rgbMTX(onj,:);
                rgb = [0 0 0];
                mk_sz = mk_sz1;
                xx = 0;

            else  
                    rgb = rgbMTX(onj,:);
                    mk_sz = mk_sz2*(210-onj)*0.1; 
                    if onj < 65
                    xx = -4
                    else
                    xx = -2;
                    end
            end

                yrand = (rand(1,1)-0.5)*2;
                zrand = (rand(1,1)-0.5)*2;
                scatter3(elecMTX_all_sorted(elecj,1)+xx,elecMTX_all_sorted(elecj,2)+yrand,elecMTX_all_sorted(elecj,3)+zrand,mk_sz,'MarkerFaceColor',rgb,'MarkerEdgeColor',rgb)
        end
    end
end
