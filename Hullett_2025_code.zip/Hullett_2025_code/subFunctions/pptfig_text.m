function pptfig_text(titleFS,xyaxFS)

%title = title fontsize
%xyax = xy axis fontsize

% sets the current figure text to correct font and font size.

set(gca,'FontSize',xyaxFS)
set(findall(gcf,'type','text'),'FontName','Helvetica');%change title and xlabel/ylabel font
set(gca,'FontName','Helvetica');%Change axis font

hh = get(gca, 'title');
set(hh, 'FontName', 'Helvetica')
set(hh, 'FontSize', titleFS)

hh = get(gca, 'xlabel');
set(hh, 'FontName', 'Helvetica')
set(hh, 'FontSize',xyaxFS)

hh = get(gca, 'ylabel');
set(hh, 'FontName', 'Helvetica')
set(hh, 'FontSize', xyaxFS)