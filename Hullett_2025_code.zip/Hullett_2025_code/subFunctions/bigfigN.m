function bigfigN(N,h,w);
%opens a figure window of the specified size. If (height) h= 1 and (width) w=1 then the figure is the size of
%computer screen screen.
%N = figure number
%h = fraction of total screen height.
%w = fraction of tital screen width. 

%Hullett

if nargin == 1
    h = 1;
    w = 1;
end

scrsz = get(0,'ScreenSize');
fign = figure(N);
set(fign,'Position',[1 1 w*round(scrsz(3)) h*round(scrsz(4))]);