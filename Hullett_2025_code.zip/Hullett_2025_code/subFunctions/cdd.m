function cdd()

cd('/Users/pcnn/Documents/MATLAB/work2/Broca/Data_Figs/Functional_Connectivity/MulanCode/plot_Mean_FC/rnd2_plotting_and_analysis/Code/subFunctions')

