function a2_2()

load('d_a2_2.mat')
bigfigN(131,.34,0.30)
hold
title(['Right Hem. Latency Dist'])
load('cvs_avg35_inMNI152_rh_pial.mat')
ctmr_gauss_plot(cortex,[0 0 0],0,'rh'); 
hold on;



%plot onsets
for elecj = 1:length(elecs_all_sorted)
    elecj
    onj = onsets_all_sorted(elecj);
    regj = region_all_sorted(elecj);


    if regj < 4 %if a suprasylvian region plot all data
            if onj>Ncent
                onj = Ncent;
                rgb = rgbMTX(onj,:);
                rgb = [0 0 0];
                mk_sz = mk_sz1;
                xx = 0;
                

            else  
                rgb = rgbMTX(onj,:);
                mk_sz = mk_sz2*(210-onj)*0.1; 
                 if onj < 65
                 xx = 4
                 else
                 xx = 2;
                 end
            end

            yrand = (rand(1,1)-0.5)*2;
            zrand = (rand(1,1)-0.5)*2;
try
            scatter3(elecMTX_all_sorted(elecj,1)+xx,elecMTX_all_sorted(elecj,2)+yrand,elecMTX_all_sorted(elecj,3)+zrand,mk_sz,'MarkerFaceColor',rgb,'MarkerEdgeColor',rgb)
catch
error
end
    else %if temporal lobe only plot random ~20% of data so the number of data points are comparable. 
        percent = 0.2;
        if rand(1) < percent %only plot percent of onsets. 
            if onj>Ncent
                onj = Ncent;
                rgb = rgbMTX(onj,:);
                rgb = [0 0 0];
                mk_sz = mk_sz1;
                xx = 0;

            else  
                    rgb = rgbMTX(onj,:);
                    mk_sz = mk_sz2*(210-onj)*0.1; 
                    if onj < 65
                    xx = 4
                    else
                    xx = 2;
                    end
            end

                yrand = (rand(1,1)-0.5)*2;
                zrand = (rand(1,1)-0.5)*2;
                scatter3(elecMTX_all_sorted(elecj,1)+xx,elecMTX_all_sorted(elecj,2)+yrand,elecMTX_all_sorted(elecj,3)+zrand,mk_sz,'MarkerFaceColor',rgb,'MarkerEdgeColor',rgb)
        end
    end
end