function run()

%runs all the subscripts
addpath(genpath(pwd))
a1_1
a1_2

a2_1
a2_2
a2_3
a2_4

a3_1


