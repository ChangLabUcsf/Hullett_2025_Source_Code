function a1_1()

load('d_a1_1.mat')


for i = 1:length(pN)    
    gridNums_mtx_pNi = electsMTXcell_ALL{pN(i),4};
    regionCount_sig_pNi = zeros(size(gridNums_mtx_pNi)); 
    electsMTX_All_sig = electsMTXcell_sig{pN(i),1};
    grid_sig_pNi = electsMTX_All_sig(:,3);% get number of sig elecs at each grid position for patient pNi
    for j = 1:size(regionCount_sig_pNi,1)
        for k = 1:size(regionCount_sig_pNi,2)
            indsig = find(grid_sig_pNi == gridNums_mtx_pNi(j,k));%find sig elects in grid position j,k
            if ~isempty(indsig)%if there are sig elecs at that grid position then cound and add to total. 
                regionCount_sig_pNi(j,k) = length(indsig);
            end
        end
    end
                
    regionCount_sig_AllpN = regionCount_sig_AllpN + regionCount_sig_pNi;% sig elec count at grid position acrosss patients.

    %get total elec number at each grid position or pNi and add it to the
    %total across patients
    regionCount_pNi = electsMTXcell_ALL{pN(i),2};
    regionCount_total_AllpN = regionCount_total_AllpN + regionCount_pNi; %all elec count at grid position acrosss patients.
  
end

prob_map = zeros(size(gridNums_mtx_pNi));

for j = 1:size(gridNums_mtx_pNi,1)
    for k = 1:size(gridNums_mtx_pNi,2)
         regionCount_sig_AllpN; 
        if regionCount_total_AllpN(j,k) ~= 0
            prob_map(j,k) = regionCount_sig_AllpN(j,k)/regionCount_total_AllpN(j,k);
        end
    end
end


ss = 30;% define sulvian sulcus. 

%zero out infrasylvian ccor
prob_map2 = prob_map;
for j = ss:size(gridNums_mtx_pNi,1)
    for k = 1:size(gridNums_mtx_pNi,2)
        
            prob_map2(j,k) = 0;
     
    end
end


%remove edge values where cortex is not well sampled. 

prob_map3 = zeros(size(gridNums_mtx_pNi));

for j = 1:size(gridNums_mtx_pNi,1)
    for k = 1:size(gridNums_mtx_pNi,2)

        if regionCount_total_AllpN(j,k) > 5
            prob_map3(j,k) = regionCount_sig_AllpN(j,k)/regionCount_total_AllpN(j,k);
        end
    end
end


for j = ss:size(gridNums_mtx_pNi,1)
    for k = 1:size(gridNums_mtx_pNi,2)
        
            prob_map3(j,k) = 0;
     
    end
end


figure(225)
title('Suprasylvian Data (Edges Zeroed, Smoothed)')
sigma = 1.5
imagesc(imgaussfilt(prob_map3,sigma))
title('Significant Response Probability Map')
colorbar
load('Dawn.mat')
colormap(Colmap_custom/255)
