function a2_4()

load('d_a2_4.mat')



[rr cc] = size(gridNums_mtx)

bar_col{1,1} = [0.9290 0.6940 0.1250]%yellow  
bar_col{2,1} = [0.8500 0.3250 0.0980]%organge 
bar_col{3,1} = [0 0.4470 0.7410];%blue    
bar_col{4,1} = [0.4940 0.1840 0.5560]% purple 
bar_col{5,1} = [0.4660 0.6740 0.1880] 
bar_col{6,1} = [0.3010 0.7450 0.9330]%light blue  
bar_col{7,1} = [0.6350 0.0780 0.1840]
bar_col{8,1} = [255 89 143]/255;



aud = cell(4,1);
audap = cell(4,60);

count = 1;

for reg = apGrig{4,1}
    aud{4,1} = [aud{4,1}; sigTIM5respsAll{reg,1}];
    audap{4,reg} = [audap{4,reg}; sigTIM5respsAll{reg,1}]; %data as a function of ap postion. 
end

%dorsal rolandic areas
aud{2,1} = [aud{2,1}; sigTIM5respsAll{2,1}];
for reg = apGrig{2,1}
    audap{2,reg} = [audap{2,reg}; sigTIM5respsAll{reg,1}]; %data as a function of ap postion. 
end

%ventral rolandic 
aud{1,1} = [aud{1,1}; sigTIM5respsAll{1,1}];%cluster defined. 
for reg = apGrig{1,1}
    audap{1,reg} = [audap{1,reg}; sigTIM5respsAll{reg,1}]; %data as a function of ap postion. %grid defined. 
end

%IFG
aud{3,1} = [aud{3,1}; sigTIM5respsAll{3,1}];
for reg = apGrig{3,1} 
    audap{3,reg} = [audap{3,reg}; sigTIM5respsAll{reg,1}]; %data as a function of ap postion. 
end


%1 = mPreCG, 2 = vSMC, 3 = IFG

title_AudArea{2,1} = ['vSMC']
title_AudArea{1,1} = ['mPreCG']
title_AudArea{3,1} = ['Inferior Frontal Gyrus']
title_AudArea{4,1} = ['Superior Temporal Gyrus']

txt_sz = 8;

xmin = 0
xmax = 2000
xax = [xmin:1:xmax];;
xax2 = [xmin:1:xmax];;%wider bins for full dist



plot_order = [4 3 2 1]% STG, IFG, vSMC, mPreCG


subplot_count = 1;

for j = 1:size(aud,1)
    
     
     if ~isempty(aud{plot_order(j),1})
                j
        
        d = aud{plot_order(j),1};
        onset_dist{plot_order(j),1} = d;

        
        figure(83)
        subplot(size(aud,1),2,j*2-1);
        [N X] = hist(d,xax)
        bar(X,N/sum(N),'FaceColor',color_rgb{plot_order(j)+20,1},'EdgeColor',color_rgb{plot_order(j) + 20,1})
        mx = max(N/sum(N));
        xlim(xlim1)
        title([title_AudArea{plot_order(j),1}])
        xlabel('Onset Latency (ms)')
        ylabel('Probability')
        ylim([0 mx*1.2])
        xticks([0 40 80 120 160])
        xticklabels({'0', '40','80', '120','160'})
        pptfig_text(txt_sz,txt_sz)


    end
        
end


%###### get data as a fuction on onset window of interest. 
plot_order = [4 1 2 3]% STG, mPreCG, vSMC, IFG
twindows = [80 120 160 200 240 [280: 40: 1520]];



datatwind = cell(4,size(twindows,2));

for twj = 1:size(twindows,2)
    for j = 1:size(aud,1)

         %get onsets within the twj temp window. 
         
         if ~isempty(aud{j,1})
                    j

            d = aud{j,1};
            iwind = find(d<= twindows(twj));%find values less than twj
            
            datatwind{j,twj} = d(iwind);

         end
    end
end

%now pairwise test each region with STG for each temp window to get pval
%mtx 

pval_mtx = ones(4,size(twindows,2));
hval_mtx = zeros(4,size(twindows,2)); %1 = sig difference. 
bonf = 0.05/(size(twindows,2));
for twj = 1:size(twindows,2)
    for j = 1:size(aud,1)
            stg_twi = datatwind{4,twj};
            areaj_twi = datatwind{j,twj};
            [h,p] = kstest2(stg_twi,areaj_twi,'alpha',bonf)
            pval_mtx(j,twj) = p;
            hval_mtx(j,twj) = h;
    end
end


%now do a grouped box plot. 


%first transpose data_twind so timepoints are rows and aud areas are colums 
%datatwind = datatwind';
datatwind_grouped = cell(size(datatwind,1),1);

for j = 1:size(datatwind,1)
    %for each row padd the data in each cell with NaNs so they are all the
    %same lenght then put them in the grouping cell (each row = time point) 

    % Create 1x3 cell array of vectors with different lengths
    C = datatwind(j,:); 
    % Pad each vector with NaN values to equate lengths
    maxNumEl = max(cellfun(@numel,C));
    Cpad = cellfun(@(x){padarray(x(:),[maxNumEl-numel(x),0],NaN,'post')}, C);
    % Convert cell array to matrix and run boxplot
    Cmat = cell2mat(Cpad(1:19)); 
    
    datatwind_grouped{j,1} = Cmat;%row = twind time point. Inside the cell is a Nx4 mtx of onset values where each column corresponds to the aud region (i.e. col4 = stg).
end

datatwind_grouped = datatwind_grouped'; %transpose again so each col is a twind point
datatwind_grouped_true =  datatwind_grouped; %make new variable so to plot with the bootstrapped data. 



%get color map for aboxplot function. 
color_map = [color_rgb{21,1}; color_rgb{22,1}; color_rgb{23,1}; color_rgb{24,1}]; 



bigfigN(2003,.18,.56)
aboxplot_noWhisker_wSig_SurprSylv(datatwind_grouped,'labels',twindows,'Colormap',color_map,'sigplot',hval_mtx);

titlej = ['Right Hemisphere Latency Distribution by Temporal Cutoff'];
title(titlej)
xlabel('Temporal Cutoff (ms)')
ylabel('Latency (ms)')
ylim([0 1250])
pptfig_text(10,10)
