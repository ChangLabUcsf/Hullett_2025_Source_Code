function a3_1()
load('d_a3_1.mat')
h = figure(309)
close(h)

bigfigN(309,.16,.27)

title_temp{1,1} = 'Left IFG'
title_temp{2,1} = 'Left VR'
title_temp{3,1} = 'Left DR'
title_temp{4,1} = 'Left STG'

title_temp{5,1} = 'Right IFG'
title_temp{6,1} = 'Right VR'
title_temp{7,1} = 'Right DR'
title_temp{8,1} = 'Right STG'

               
regions_temp = [3 2 1 4];
plot_temp = [1 2 3];
data_temp= [1 3 6];%data to plot BF, SRF, TRF

lr_hem_area_means = cell(1,2,10);% col1 = lef col2 = right, z = data type. each cell contains the mean for each area 
for dataj = 1:length(data_temp)%for each data type
    %get and plot the left sided RF data
    for k = 1:2
        if k == 1
            subplot(2,3,plot_temp(dataj));
            hold
        elseif k == 2   
            subplot(2,3,plot_temp(dataj)+3);
            hold
        end
             
        for j = 1:length(regions_temp)
       

                 data = strf_data{regions_temp(j),k,data_temp(dataj)};

                 if data_temp(dataj) == 1
                     xax = oct;
                     [N xax] = hist(data,xax)
                     %bar(xax,N/sum(N))
                     p = N/sum(N)
                     plot(xax,p,'Color',color_rgb{20+ regions_temp(j),1},'LineWidth',1)
                     title(['STRF Best Freq.'])
                     ylabel('Prob.')
                     xlabel('BF (kHz)')
                     xticks([0 2 4 6])
                     xticklabels({'.125','0.5','2','8'})
                     pptfig_text(8,8)
                     
                 elseif data_temp(dataj) == 2
                     xax = [10:30:800];
                     [N xax] = hist(data*10,xax)
                     p = N/sum(N)
                     cdf_peak_latency = cumsum(N/sum(N));
                  
                     %plot CDF instead of peak latency distributioin 
                     plot(xax,cdf_peak_latency,'Color',color_rgb{20+ regions_temp(j),1})
                     title(['Peak Latency CDF'])
                     ylim([0 1])
                     
                     % 
                     ylabel('Prob.')
                     xlabel('Latency (ms)')
                     pptfig_text(8,8)
                     

                 elseif data_temp(dataj) == 3
                     
                     lr_hem_area_means{1,k,data_temp(dataj)} = [lr_hem_area_means{1,k,data_temp(dataj)}; mean(data,1)]; 
                     stdshade_ph(data,.45,color_rgb{20+ regions_temp(j),1},oct,[])
                     title(['Spectral Tuning'])
                     ylabel(['\beta' ' Weight'])
                     xlabel('Freq. (kHz)')
                     xticks([0 2 4 6])
                     xticklabels({'.125','0.5','2','8'})
                     pptfig_text(8,8)


                 elseif data_temp(dataj) == 4
                      stdshade(data,[],[],fax,[])
                      title([title_temp{title_num,1} 'Freq_neg'])

                 elseif data_temp(dataj) == 5
                      stdshade(data,[],[],fax,[])
                      title([title_temp{title_num,1} 'Freq_pos'])


                 elseif data_temp(dataj) == 6
                      lr_hem_area_means{1,k,data_temp(dataj)} = [lr_hem_area_means{1,k,data_temp(dataj)}; mean(data,1)]; 
                      x_temp = [-800:10:-10];
                      stdshade_ph(data,.45,color_rgb{20+ regions_temp(j),1},x_temp,[])
                      title(['Temporal Tuning'])
                      ylabel('\beta Weight')
                      xlabel('Time (ms)')
                      pptfig_text(8,8)

                 elseif data_temp(dataj) == 7
                     stdshade(data,[],[],fax,[])
                      title([title_temp{title_num,1} 'Temp_neg'])

                 elseif data_temp(dataj) == 8
                     stdshade(data,[],[],fax,[])
                      title([title_temp{title_num,1} 'Temp_pos'])

                 end
      

        end
    end
end
pptfig_text(8,8)



figure(309)
lw = 1.3;%hem mean linewidth. 
%*** temp tuning 
%right hem mean on left hem plot
subplot(2,3,3)
dataj = 6;%temporal data
plot(x_temp,mean(lr_hem_area_means{1,2,dataj},1),':k','LineWidth',lw);

%left hem mean on right hem plot
subplot(2,3,6)
dataj = 6;%temporal data
plot(x_temp,mean(lr_hem_area_means{1,1,dataj},1),':k','LineWidth',lw);

%*** spectral tuning
subplot(2,3,2)
dataj = 3;%temporal data
plot(oct,mean(lr_hem_area_means{1,2,dataj},1),':k','LineWidth',lw);

%left hem mean on right hem plot
subplot(2,3,5)
dataj = 3;%temporal data
plot(oct,mean(lr_hem_area_means{1,1,dataj},1),':k','LineWidth',lw);



%get BF sig testing for each hem and both him

%strf_data{regions_temp(j),k,1} = [strf_data{regions_temp(j),k,1}; BF];
dataj = 1;% BF data
pvec=[1; 1; 1];%1 = left hem, 2 = right hem, 3 = both hem
hemdata = cell(2,1); %row 1 = left, row 2 = rigt. 
groupV = cell(2,1); %groupng variable that specifies region each data point comes from. row 1 = left, row 2 = rigt. 
for k = 1:2%for each hem
    for regj = [1:4];
        hemdata{k,1} = [hemdata{k,1} strf_data{regj,k,1}'];
        groupV{k,1} = [groupV{k,1} ones(size(strf_data{regj,k,1}'))*regj];%make grouping variable. 
    end
    pvec(k) =  kruskalwallis(hemdata{k,1},groupV{k,1},'off')
end

%test all regions from both hem
pvec(3) =  kruskalwallis([hemdata{1,1} hemdata{2,1}],[groupV{1,1},groupV{2,1}],'off')

'kruskalwallis left hem'
pvec(1)
'kruskalwallis right hem'
pvec(2)
'kruskalwallis left and righ hem'
pvec(3)

        
%data type key

data_type{1,1} = 'BF';
data_type{2,1} = 'Peak Latency';
data_type{3,1} = 'Frequency Tuning';
data_type{6,1} = 'Temporal Tuning';



%top rows and first colums (bottom are left)
title_key{1,1} = 'L DR'
title_key{2,1} = 'L VR'
title_key{3,1} = 'L IFG'
title_key{4,1} = 'L STG'

title_key{5,1} = 'R DR'
title_key{6,1} = 'R VR'
title_key{7,1} = 'R IFG'
title_key{8,1} = 'R STG'

regions2 = [1 2 4 3 5 6 8 7];


%now the figure data (left and right split, all regions in one plot) BFF,
%spetral tuning, temporal tuning
h = figure(310)
close(h)

bigfigN(310,.16,.27)


               
regions_temp = [3 2 1 4];
plot_temp = [1 2 3];
data_temp= [6 6];%data to plot BF, SRF, peak lat, TRF

lr_hem_area_means = cell(1,2,10);% col1 = left col2 = right, z = data type. each cell contains the mean for each area 
count = 1;%needed because btm and bsm are both in data_temp = 6;
for dataj = 1:length(data_temp)%for each data type
    %get and plot the left sided RF data
    for k = 1:2
        if k == 1
            subplot(2,3,plot_temp(dataj));
            hold
        elseif k == 2   
            subplot(2,3,plot_temp(dataj)+3);
            hold
        end
             
        for j = 1:length(regions_temp)
       
          
                 d    = c_dist_coor_elec_pN_reg_all_LR{regions_temp(j),k,6};
                 data = d(:,count);

                 if data_temp(dataj) == 1
                     xax = oct;
                     [N xax] = hist(data,xax)
                     p = N/sum(N)
                     plot(xax,p,'Color',color_rgb{20+ regions_temp(j),1},'LineWidth',1)
                     title(['STRF Best Freq.'])
                     ylabel('Prob.')
                     xlabel('BF (kHz)')
                     xticks([0 2 4 6])
                     xticklabels({'.125','0.5','2','8'})
                     pptfig_text(8,8)
                     
                 elseif data_temp(dataj) == 2
                     xax = [10:30:800];
                     [N xax] = hist(data*10,xax)
                     p = N/sum(N)
                     cdf_peak_latency = cumsum(N/sum(N));
                  
                     plot(xax,cdf_peak_latency,'Color',color_rgb{20+ regions_temp(j),1})
                     title(['Peak Latency CDF'])
                     ylim([0 1])
                     
                     % 
                     ylabel('Prob.')
                     xlabel('Latency (ms)')
                     pptfig_text(8,8)
                     

                 elseif data_temp(dataj) == 3
                     
                     lr_hem_area_means{1,k,data_temp(dataj)} = [lr_hem_area_means{1,k,data_temp(dataj)}; mean(data,1)]; 
                     stdshade_ph(data,.45,color_rgb{20+ regions_temp(j),1},oct,[])
                     title(['Spectral Tuning'])
                     ylabel(['\beta' ' Weight'])
                     xlabel('Freq. (kHz)')
                     xticks([0 2 4 6])
                     xticklabels({'.125','0.5','2','8'})
                     pptfig_text(8,8)


                 elseif data_temp(dataj) == 4
                      stdshade(data,[],[],fax,[])
                      title([title_temp{title_num,1} 'Freq_neg'])

                 elseif data_temp(dataj) == 5
                      stdshade(data,[],[],fax,[])
                      title([title_temp{title_num,1} 'Freq_pos'])


                 elseif data_temp(dataj) == 6 & count == 1

                     xax = [0:0.75:3.75];
                     [N xax] = hist(data,xax)
                     p = N/sum(N)
                     plot(xax,p,'Color',color_rgb{20+ regions_temp(j),1},'LineWidth',2.5)
                     title(['Best Temp. Mod. Distribution'])
                     ylabel('Prob.')
                     xlabel('Temp. Mod.(Hz)')
                     xticks([0 1 2 3])
                     xticklabels({'0','1','2','3'})
                     pptfig_text(8,8)

                  elseif data_temp(dataj) == 6 & count == 2
                    

                     xax = [0:0.05:.35];
                     [N xax] = hist(data,xax)
                     p = N/sum(N)
                     plot(xax,p,'Color',color_rgb{20+ regions_temp(j),1},'LineWidth',2.5)
                     title(['Best Spec. Mod. Distribution'])
                     ylabel('Prob.')
                     xlabel('Spec. Mod.(cyc./oct.)')

                     pptfig_text(8,8)    

                 elseif data_temp(dataj) == 7
                     stdshade(data,[],[],fax,[])
                      title([title_temp{title_num,1} 'Temp_neg'])

                 elseif data_temp(dataj) == 8
                     stdshade(data,[],[],fax,[])
                      title([title_temp{title_num,1} 'Temp_pos'])

                 end
      
                


        end
    end
    count = count + 1;
end
pptfig_text(8,8)


dataj = 1;% BF data
pvec=[1; 1; 1];%1 = left hem, 2 = right hem, 3 = both hem
hemdata = cell(2,1); %row 1 = left, row 2 = right. 
groupV = cell(2,1); %groupng variable that specifies region each data point comes from. row 1 = left, row 2 = right. 
for k = 1:2%for each hem
    for regj = [1:4];
        hemdata{k,1} = [hemdata{k,1} strf_data{regj,k,1}'];
        groupV{k,1} = [groupV{k,1} ones(size(strf_data{regj,k,1}'))*regj];%make grouping variable. 
    end
    pvec(k) =  kruskalwallis(hemdata{k,1},groupV{k,1},'off')
end

%test all regions from both hem
pvec(3) =  kruskalwallis([hemdata{1,1} hemdata{2,1}],[groupV{1,1},groupV{2,1}],'off')

'kruskalwallis left hem'
pvec(1)
'kruskalwallis right hem'
pvec(2)
'kruskalwallis left and righ hem'
pvec(3)



%% 
%plot avg mtf for each region. 

%now the figure data (left and right split, all regions in one plot) BFF,
%spetral tuning, temporal tuning
h = figure(311)
close(h)

bigfigN(311,.16,.27)
regions_temp = [1 2 3 4];
plot_temp = [1 2 3 4];



load('RedBlue.mat')
colormap(Colmap_custom/255)

lr_hem_area_means = cell(1,2,10);% col1 = lef col2 = right, z = data type. each cell contains the mean for each area 
count = 1;%needed because btm and bsm are both in data_temp = 6;

        dataj = 7
        for j = 1:length(regions_temp)
             for k = 1:2
                if k == 1
                    subplot(2,4,plot_temp(j));
                    titlej = title_temp{plot_temp(j),1}
                    hold
                    d    = c_dist_coor_elec_pN_reg_all_LR{regions_temp(j),k,7};
                    data = mean(d,3);
                elseif k == 2   
                    subplot(2,4,plot_temp(j)+4);
                    titlej = title_temp{plot_temp(j)+4,1}
                    hold
                    
                    d    = c_dist_coor_elec_pN_reg_all_LR{regions_temp(j),k,7};
                    data = mean(d,3);
                end

                            xlims = [-10 10];
                            ylims = [0 0.65];                         
                            imagesc(MTF_xax,MTF_yax,flipud(data))
                            title([titlej ' eMTF']);
                            if j == 1
                                xlabel('Temp Mod. (Hz)')
                                ylabel('Spec Mod. (cyc/oct)')
                            end
                            xlim(xlims);
                            ylim(ylims)
                            axis xy
                            pptfig_text(8,8)
                            dataj
                 
             end

        end
    count = count + 1;
pptfig_text(8,8)
